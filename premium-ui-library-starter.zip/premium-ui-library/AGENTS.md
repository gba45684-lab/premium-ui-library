# UI/UX implementation instructions

When asked to create or redesign UI/UX in this repository, consult `UI_UX_RULES.md` and the central design-system reference if accessible.

## Mandatory workflow
1. Inspect the existing app before changing code. Identify framework, build/test commands, current screens, routes, state, APIs and platform constraints.
2. Preserve all existing functionality, data contracts, navigation, permissions, analytics, monetization and accessibility unless the user explicitly asks to change them.
3. Pick a single primary style preset from `presets/STYLE_PRESETS.md`; optionally combine one supporting motif. Avoid mixing unrelated styles.
4. Use open-source libraries only after verifying the upstream repository, current maintenance, framework compatibility and license. Do not copy proprietary assets or paid components.
5. Reuse existing dependencies where sensible. Do not add a large UI framework for a small isolated component without justification.
6. Implement responsive layouts and meaningful loading, empty, error, success and disabled states.
7. Respect reduced-motion preferences; ensure readable contrast, focus visibility, semantic controls, labels and keyboard/touch support.
8. Run available lint, type-check, tests and build. If a command cannot run, state that clearly.
9. Summarize files changed, design decisions, tests and known limitations.
10. Prefer a feature branch and pull request. Never force-push, delete user data, overwrite secrets, or make a breaking production change without explicit authorization.

## Visual quality bar
- Clear hierarchy, consistent spacing, restrained typography, intentional color and coherent iconography.
- Compact but comfortable layouts; touch targets should remain usable on phones.
- Effects such as blur, glow, gradients and shadows must not harm performance or legibility.
- Use CSS variables/design tokens instead of scattered one-off values.
- Avoid fake device frames, decorative backgrounds behind every screen, unnecessary gradients, excessive cards and gratuitous animations.
