# Premium UI Library — Reusable Design System

A framework-aware reference library for premium, accessible UI/UX across current and future apps.

## What this repository is for
- One source of truth for design principles, tokens, presets, component patterns and implementation instructions.
- Use the right preset for each product; do not apply every visual effect to every screen.
- Preserve existing product features and business logic during redesigns.
- Prefer accessible, responsive, performant interfaces over decorative effects.

## Presets
See [`presets/STYLE_PRESETS.md`](presets/STYLE_PRESETS.md):
- Glassmorphism / frosted glass
- Liquid Glass-inspired (original implementation; do not copy proprietary assets)
- Bento Grid
- Premium Minimalism
- Neumorphism / Soft UI
- Aurora / Gradient
- Material Design 3
- Dark Luxury
- Neobrutalism / Modern Brutalism
- Claymorphism
- Editorial / Swiss
- Neon / Cyberpunk
- 3D / depth-inspired UI

## How to use
1. Inspect the target app's framework, routing, design conventions, dependencies and tests.
2. Select one primary preset and at most one supporting visual motif.
3. Map existing screens and interactions before editing.
4. Apply tokens and shared components incrementally.
5. Verify responsive behavior, keyboard navigation, contrast, reduced motion and existing functionality.
6. Open a pull request with screenshots/summary and tests; never silently overwrite production code.

## Compatibility
This is a design reference, not a universal drop-in package. React/web libraries may not work in plain HTML, Capacitor, native Android, SwiftUI or other stacks without adaptation. Use each source library's official installation guide and license.
