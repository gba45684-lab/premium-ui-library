# UI/UX rules

## Design principles
- Product-first, polished, compact, professional and responsive.
- Establish hierarchy through typography, spacing, alignment and color before adding effects.
- Define design tokens for color, typography, spacing, radii, borders, elevation, motion and breakpoints.
- Keep interaction states consistent across the product.
- Ensure WCAG-oriented contrast, visible focus, semantic HTML, labels, reduced motion and accessible error messages.
- Test narrow mobile, large mobile, tablet and desktop layouts.
- Respect the platform: web, Capacitor, Android, iOS and desktop need appropriate patterns.

## Preset selection
- Use Glassmorphism for selective overlays, navigation, floating panels or hero sections—not for every content surface.
- Use Liquid Glass-inspired treatment sparingly and implement original styles; do not imply affiliation with Apple or copy proprietary assets.
- Use Bento Grid for dashboards, feature discovery and modular summaries.
- Use Premium Minimalism for productivity, finance, documents and professional tools.
- Use Material Design 3 for Android-first apps and familiar adaptive controls.
- Use Neumorphism only for limited low-risk decorative controls; avoid low contrast and ambiguous affordances.
- Use Aurora/Gradient for emphasis, hero areas and brand moments, not body-text backgrounds.
- Use Dark Luxury for deliberate premium experiences with clear contrast.
- Use Neobrutalism/Modern Brutalism for bold, editorial products where the brand supports it.
- Use Claymorphism for friendly, playful interfaces.
- Use Editorial/Swiss for content-heavy, typographic experiences.
- Use Neon/Cyberpunk only when appropriate to product audience and usability.
- Use 3D/depth-inspired UI sparingly; respect reduced-motion and device performance.

## Suggested tokens
Start with semantic tokens rather than fixed brand assumptions:
- `--color-bg`, `--color-surface`, `--color-text`, `--color-muted`
- `--color-primary`, `--color-accent`, `--color-border`, `--color-danger`, `--color-success`
- `--space-1` through `--space-8`
- `--radius-sm`, `--radius-md`, `--radius-lg`, `--radius-xl`
- `--shadow-sm`, `--shadow-md`, `--shadow-lg`
- `--motion-fast`, `--motion-standard`
- `--content-max`, `--page-gutter`

## Glassmorphism safeguards
- Keep text on a sufficiently opaque surface when the background is variable.
- Use blur as enhancement, not as the only way to separate content.
- Provide a solid-color fallback when `backdrop-filter` is unsupported.
- Avoid glass over busy imagery and avoid blur-heavy full-screen layers on low-power devices.
