# Open-source UI/UX resources

Verify the current license and framework fit at the upstream repository before adding code or assets. License terms and repository status can change.

- shadcn/ui — https://github.com/shadcn-ui/ui
- Radix Primitives — https://github.com/radix-ui/primitives
- Magic UI — https://github.com/magicuidesign/magicui
- Aceternity UI — https://github.com/aceternity/aceternity-ui
- React Aria Components — https://github.com/adobe/react-spectrum
- Mantine — https://github.com/mantinedev/mantine
- Material Web — https://github.com/material-components/material-web
- Tailwind CSS — https://github.com/tailwindlabs/tailwindcss
- Lucide icons — https://github.com/lucide-icons/lucide

These resources are not all interchangeable and do not all target the same framework. Confirm license, dependency weight, accessibility, maintenance and compatibility before use. Do not assume every component showcased on a site is open source or available under the same license.
