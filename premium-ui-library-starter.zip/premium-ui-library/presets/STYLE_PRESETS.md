# Style preset catalog

Each project should choose one primary preset and no more than one supporting motif. Build original designs using these descriptions and verified open-source resources.

## 1. Glassmorphism
Frosted translucent surfaces, subtle borders, background blur and layered depth. Best for overlays, navigation, dialogs and select hero cards. Maintain legibility and fallback surfaces.

## 2. Liquid Glass-inspired
Fluid translucent layers, specular highlights and subtle depth. Use an original, platform-appropriate interpretation; avoid copying proprietary UI assets or implying official affiliation.

## 3. Bento Grid
Modular cards of varied sizes, consistent grid rhythm, concise information hierarchy and responsive reflow. Best for dashboards, feature discovery and overview pages.

## 4. Premium Minimalism
Generous whitespace, restrained palette, crisp typography, subtle borders and precise alignment. Best for finance, productivity, document and professional apps.

## 5. Neumorphism / Soft UI
Soft inset/raised surfaces and gentle shadows. Use selectively; ensure controls remain recognizable and contrast is sufficient.

## 6. Aurora / Gradient
Atmospheric gradients and controlled color transitions for focal areas. Keep text surfaces readable and avoid gradients on every component.

## 7. Material Design 3
Adaptive components, tonal color, clear states and platform-familiar interactions. Strong choice for Android-first experiences.

## 8. Dark Luxury
Deep neutral surfaces, restrained metallic/accent colors, strong typography and carefully controlled highlights. Keep text contrast high.

## 9. Neobrutalism / Modern Brutalism
Bold typography, hard borders, high-contrast blocks and deliberate asymmetry. Use when the product brand supports a strong visual statement.

## 10. Claymorphism
Rounded, soft, dimensional surfaces and friendly illustration-like forms. Better for approachable consumer products than dense professional dashboards.

## 11. Editorial / Swiss
Grid-led composition, typographic hierarchy, strong alignment and intentional whitespace. Good for content, learning and portfolio products.

## 12. Neon / Cyberpunk
Dark surfaces, bright accent colors and luminous outlines. Use sparingly; preserve readable text and avoid constant glow/animation.

## 13. 3D / Depth-inspired
Layering, perspective and restrained depth cues. Use only where it improves comprehension; respect reduced motion and device performance.

## Recommended defaults by product
- Finance / wealth / professional tools: Premium Minimalism or Material Design 3.
- Resume / document tools: Premium Minimalism with restrained Bento Grid.
- Dashboards: Bento Grid.
- Brand-forward landing pages: Aurora accents or selective Glassmorphism.
- Playful consumer apps: Claymorphism.
Always adapt to existing brand, platform, users and technical stack.
