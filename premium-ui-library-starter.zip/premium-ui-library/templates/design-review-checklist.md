# UI/UX review checklist

- [ ] Existing functionality and navigation preserved
- [ ] One clear primary style preset chosen
- [ ] Shared tokens used consistently
- [ ] Mobile layout tested at narrow widths
- [ ] Tablet and desktop layouts tested where applicable
- [ ] Contrast, focus and keyboard navigation checked
- [ ] Touch targets and form labels checked
- [ ] Loading, empty, error, success and disabled states covered
- [ ] Reduced-motion preference respected
- [ ] Blur, shadows, gradients and animation kept purposeful
- [ ] No unlicensed assets or copied proprietary UI
- [ ] Lint, type-check, tests and build run where available
- [ ] Screenshots and summary included in pull request
